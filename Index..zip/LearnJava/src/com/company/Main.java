package com.company;

public class Main {

    public static void main(String[] args) {

        int hours = 6;
        int convertHours  = hours * 60 ;
        System.out.println(convertHours);


    }
}
