package com.company;

public class Squad {
    public static void main(String[] args) {

        int numOne = 1;
        numOne *= numOne;
        int numTwo = 2;
        numTwo *= numTwo;
        int numThtee = 3;
        numThtee*= numThtee;
        int findArifmetic = (numOne + numTwo+ numThtee)/2;
        System.out.println(findArifmetic);

    }
}