package com.company;

public class Triangle {

    public static void main(String[] args) {

        int A = 3;
        int B = 2;
        int areaTriangle = (A * B)/ 2;
        System.out.println(areaTriangle);
    }
}