public class Kelvin {

        public static void main(String[] args) {
            double kelvin = 333;
            double celcius = kelvin *273.6;
            System.out.println(celcius);
        }
        }
